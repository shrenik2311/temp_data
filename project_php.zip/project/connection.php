<?php

class Connection{
    private $host = 'localhost';
    private $user = 'root';
    private $pass = '';
    private $db = 'core_php_project';

    public function connect(){
        $mysqli = new mysqli($this->host,$this->user,$this->pass,$this->db);

        // Check connection
        if ($mysqli->connect_errno) {
        echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
        exit();
        }else{
            return $mysqli;
        }
    }

}

?>