<?php

require './User.php';

session_start();
$cookieValue = $_COOKIE['key'];
$sessionValue = $_SESSION['key'];
if($cookieValue === $sessionValue){
    
    if(isset($_POST['login'])){

                function getName($n) {
                    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    $randomString = '';
                
                    for ($i = 0; $i < $n; $i++) {
                        $index = rand(0, strlen($characters) - 1);
                        $randomString .= $characters[$index];
                    }
                
                    return $randomString;
                }
                
                function getIPAddress() {  
                    //whether ip is from the share internet  
                    if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                                $ip = $_SERVER['HTTP_CLIENT_IP'];  
                        }  
                    //whether ip is from the proxy  
                    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
                    }  
                    //whether ip is from the remote address  
                    else{  
                            $ip = $_SERVER['REMOTE_ADDR'];  
                    }  
                    return $ip;  
                }  
                
                $ip = getIPAddress(); 
                $key = getName(20); 
                
                setcookie("key", $ip.'_'.$key);  
                $_SESSION['key'] = $ip.'_'.$key;

                extract($_POST);
                $username = trim(stripslashes($username));
                $password = trim(stripslashes($password));

                $user = new User();
                $my_user = $user->getRowData($username);
                if(count($my_user) > 0){
                    if($my_user['vPassword'] == sha1($password)){
                        $_SESSION['user'] = $my_user;
                        header('Location: dashboard.php');
                        exit;
                    }else{
                        $_SESSION['log_err'] = 'invalid username or password';
                    } 
                }
                $_SESSION['log_err'] = 'invalid username or password';
                header('Location: index.php');
    }
    header('Location: index.php');
}
header('Location: index.php');

?>