<?php

    require './User.php';

    session_start();
    $cookieValue = $_COOKIE['key'];
    $sessionValue = $_SESSION['key'];
    if($cookieValue === $sessionValue){
        
        if(isset($_POST['register'])){
                

                //php validation
                extract($_POST);
                $firstname = trim(stripslashes($firstname));
                $lastname = trim(stripslashes($lastname));
                $username = trim(stripslashes($username));
                $pass = trim(stripslashes($pass));
                $conf_pass = trim(stripslashes($pass));

                //validating password
                $uppercase = preg_match('@[A-Z]@', $pass);
                $lowercase = preg_match('@[a-z]@', $pass);
                $number    = preg_match('@[0-9]@', $pass);
                $specialChars = preg_match('@[^\w]@', $pass);   

                function getName($n) {
                    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    $randomString = '';
                 
                    for ($i = 0; $i < $n; $i++) {
                        $index = rand(0, strlen($characters) - 1);
                        $randomString .= $characters[$index];
                    }
                 
                    return $randomString;
                }
                
                function getIPAddress() {  
                    //whether ip is from the share internet  
                     if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                                $ip = $_SERVER['HTTP_CLIENT_IP'];  
                        }  
                    //whether ip is from the proxy  
                    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
                     }  
                    //whether ip is from the remote address  
                    else{  
                             $ip = $_SERVER['REMOTE_ADDR'];  
                     }  
                     return $ip;  
                }  
                
                $ip = getIPAddress(); 
                $key = getName(20); 
                
                setcookie("key", $ip.'_'.$key);  
                $_SESSION['key'] = $ip.'_'.$key;
                
                if($firstname !== null && $firstname !== '' && preg_match("/^[a-zA-Z\s]+$/",$firstname)){
                    if($lastname !== null && $lastname !== '' && preg_match("/^[a-zA-Z\s]+$/",$lastname)){
                        if($username !== null && $username !== '' && preg_match("/^[a-zA-Z0-9\s]+$/",$username)){
                            if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($pass) < 8){
                                $_SESSION['err'] = "Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.";
                            }else{
                                if($conf_pass === $pass){
                                    $user = new User();
                                    $users = $user->getAllData();
                                    foreach($users as $row){
                                        if($row['vUsername'] == $username){
                                            $_SESSION['err'] = 'sorry this user name already exists try another';
                                            header('Location: index.php');
                                        }
                                    }
                                    if($user->insertData($_POST)){
                                        $_SESSION['user'] = $user->getRowData($username);
                                        header('Location: dashboard.php');
                                    }else{
                                        echo "internal server error";
                                        exit;
                                    }
                                }else{
                                    $_SESSION['err'] = "both the passwords should be matched";
                                }
                            }
                        }else{
                            $_SESSION['err'] = "alphanets and numbers only are allowed as username";
                        }
                    }else{
                        $_SESSION['err'] = "invalid lastname";
                    }
                }else{
                    $_SESSION['err'] = "invalid firstname";
                }
            header('Location: index.php');
        }
        header('Location: index.php');
    }

    header('Location: index.php');


?>