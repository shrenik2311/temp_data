<?php

//csrf authentication
//client side
session_start();

function getName($n) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
 
    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }
 
    return $randomString;
}

function getIPAddress() {  
    //whether ip is from the share internet  
     if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                $ip = $_SERVER['HTTP_CLIENT_IP'];  
        }  
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
     }  
    //whether ip is from the remote address  
    else{  
             $ip = $_SERVER['REMOTE_ADDR'];  
     }  
     return $ip;  
}  

$ip = getIPAddress(); 
$key = getName(20); 

setcookie("key", $ip.'_'.$key);  
$_SESSION['key'] = $ip.'_'.$key;

if(isset($_SESSION['user'])){
	if('array' == gettype($_SESSION['user'])){
		header('Location: dashboard.php');
	}
}

?>
<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html lang="zxx">

<head>
	<title>Validate Login & Register Forms Flat Responsive Widget Template :: w3layouts</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Validate Login & Register Forms Responsive Widget,Login form widgets, Sign up Web forms , Login signup Responsive web form,Flat Pricing table,Flat Drop downs,Registration Forms,News letter Forms,Elements" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- Meta tag Keywords -->

	<!-- css files -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //css files -->
	<!-- web-fonts -->
	<link href="//fonts.googleapis.com/css?family=Magra:400,700&amp;subset=latin-ext" rel="stylesheet">
	<!-- //web-fonts -->
</head>

<body>
	<!-- title -->
	<h1>
		Login & Register Forms
	</h1>
	<!-- //title -->

	<!-- content -->
	<div class="container-agille">
		<div class="formBox level-login">
			<div class="box boxShaddow"></div>
			<div class="box loginBox">
				<h3>Login Here</h3>
				<?php
				if(isset($_SESSION['log_err'])){
					echo "<p style='color:red; margin-left:10px;'>".$_SESSION['log_err']."</p>";
					$_SESSION['log_err'] = null;
				}

				?>
				<form class="form" action="login.php" method="post">
					<div class="f_row-2">
						<input type="text" class="input-field" placeholder="Username" name="username" required>
					</div>
					<div class="f_row-2 last">
						<input type="password" name="password" placeholder="Password" class="input-field" required>
					</div>
					<input class="submit-w3" type="submit" name="login" value="Login">
				</form>
			</div>
			<div class="box forgetbox agile">
				<a href="#" class="back icon-back">
					<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					 viewBox="0 0 199.404 199.404" style="enable-background:new 0 0 199.404 199.404;" xml:space="preserve">
						<polygon points="199.404,81.529 74.742,81.529 127.987,28.285 99.701,0 0,99.702 99.701,199.404 127.987,171.119 74.742,117.876 
			  199.404,117.876 " />
					</svg>
				</a>
				<h3>Reset Password</h3>
				<form class="form" action="#" method="post">
					<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium.</p>
					<div class="f_row last">
						<label>Email Id</label>
						<input type="email" name="email" placeholder="Email" class="input-field" required>
						<u></u>
					</div>
					<button class="btn button submit-w3">
						<span>Reset</span>
					</button>
				</form>
			</div>
			<div class="box registerBox wthree">
				<span class="reg_bg"></span>
				<h3>Register</h3>
				<?php
				
				if(isset($_SESSION['err'])){
					echo "<p style='color:red; margin-left:50px;'>".$_SESSION['err']."</p>";
					$_SESSION['err'] = null;
				}
				
				?>
				<form class="form" action="Register.php" method="post">
				
					<div class="f_row-2">
						<input type="text" class="input-field name" placeholder="Firstname" name="firstname" required>
					</div>
					<div class="f_row-2">
						<input type="text" class="input-field name" placeholder="Lastname" name="lastname" required>
					</div>
					<div class="f_row-2">
						<input type="date" class="input-field" placeholder="birthdate" name="birthdate" required>
					</div>
					<div class="f_row-2">
						<input type="text" class="input-field" placeholder="username" name="username" required>
					</div>
					<div class="f_row-2 last">
						<input type="password" name="pass" placeholder="Password" id="password1" class="input-field" required>
					</div>
					<div class="f_row-2 last">
						<input type="password" name="conf_pass" placeholder="Confirm Password" id="password2" class="input-field" required>
					</div>
					<input class="submit-w3" name="register" type="submit" value="Register">
				</form>
			</div>
			<a href="#" class="regTag icon-add">
				<i class="fa fa-repeat" aria-hidden="true"></i>

			</a>
		</div>
	</div>
	<!-- //content -->

	<!-- copyright -->
	<div class="footer-w3ls">
		<h2>&copy; 2018 Validate Login & Register Forms. All rights reserved | Design by
			<a href="http://w3layouts.com">W3layouts</a>
		</h2>
	</div>
	<!-- //copyright -->


	<!-- js files -->
	<!-- Jquery -->
	<script src="js/jquery-2.2.3.min.js"></script>
	<!-- //Jquery -->
	<!-- input fields js -->
	<script src="js/input-field.js"></script>
	<!-- //input fields js -->

	<!-- password-script -->
	<script>
		window.onload = function () {
			document.getElementById("password1").onchange = validatePassword;
			document.getElementById("password2").onchange = validatePassword;
		}

		function validatePassword() {
			var pass2 = document.getElementById("password2").value;
			var pass1 = document.getElementById("password1").value;
			if (pass1 != pass2)
				document.getElementById("password2").setCustomValidity("Passwords Don't Match");
			else
				document.getElementById("password2").setCustomValidity('');
			//empty string means no validation error
		}

		
        $("#name").keypress(function(e) {
            if (e.which == 32) {
                return true;
            } else if (e.which > 31 && (e.which < 65 || e.which > 90) && (e.which < 97 || e.which >
                    122) || e.which == 13) {
                return false;
            }
            if ($(this).val().length > 30) {
                return false;
            }
        });

        $("#phone").keypress(function(e) {

            if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                return false;
            }
            if ($(this).val().length > 9) {
                return false;
            }
        });

        $("#phone").change(function(e) {
            $(this).parent().closest(".form-group").find('.phoneErr').remove();

            if ($(this).val().length != 10 || !$.isNumeric($(this).val())) {
                $(this).parent().closest(".form-group").append(
                    '<div style="color:red" class="phoneErr" >Enter 10 digit valid number</div>'
                );
                $(this).val("");
            }
        });
 


	$(".name").keypress(function(e) {
            if (e.which == 32) {
                return true;
            } else if (e.which > 31 && (e.which < 65 || e.which > 90) && (e.which < 97 || e.which >
                    122) || e.which == 13) {
                return false;
            }
            if ($(this).val().length > 30) {
                return false;
            }
        });

        $(".phone").keypress(function(e) {

            if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                return false;
            }
            if ($(this).val().length > 9) {
                return false;
            }
        });

        $(".phone").change(function(e) {
            $(this).parent().closest(".form-group").find('.phoneErr').remove();

            if ($(this).val().length != 10 || !$.isNumeric($(this).val())) {
                $(this).parent().closest(".form-group").append(
                    '<div style="color:red" class="phoneErr" >Enter 10 digit valid number</div>'
                );
                $(this).val("");
            }
        });


    


	</script>
	<!-- //password-script -->
	<!-- //js files -->


</body>

</html>