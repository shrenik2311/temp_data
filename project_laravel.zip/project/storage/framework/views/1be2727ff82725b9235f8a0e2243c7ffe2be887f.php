 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset("style.css")); ?>">
</head>
<body>
    <div class="operations"> 
        <?php if(auth()->guard()->check()): ?>
            <span class=""><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></span><br><br>
        <?php else: ?>
            <span class=""><a href="<?php echo e(route('login')); ?>">Log in</a></span><br><br>
            <span class=""><a href="<?php echo e(route('register')); ?>">Register</a></span>

        <?php endif; ?>
    </div>
</body>
</html>
 <?php /**PATH C:\xampp\htdocs\temp\project\resources\views/welcome.blade.php ENDPATH**/ ?>