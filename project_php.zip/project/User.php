<?php
                    require "connection.php";
                    
                    class User{
                        private $con,$conn;
                        public function __construct()
                        {
                            $this->con = new Connection();
                            $this->conn = $this->con->connect();
                        }


                        //getting data
                        public function getAllData(){
                            $query = "select * from users;";
                            if($resset = $this->conn->query($query)){
                                if($resset->num_rows > 0){
                                    $resset = $resset->fetch_all(MYSQLI_ASSOC);
                                    return $resset;
                                }else{
                                    return Array('data' => 'no data found');
                                }             
                            }
                        }
                        public function getRowData($username){
                            $query = "select * from users where vUsername='$username';";
                            if($resset = $this->conn->query($query)){
                                if($resset->num_rows > 0){
                                    $resset = $resset->fetch_assoc();
                                    return $resset;
                                }else{
                                    return Array('data' => 'no data found');
                                }
                              
                            }
                        }
                    public function getIId($id){
                            $query = "select iId from users  where iId=$id;";
                            if($resset = $this->conn->query($query)){
                                return $resset;
                            }
                        }public function getVUsername($id){
                            $query = "select vUsername from users where iId=$id;";
                            if($resset = $this->conn->query($query)){
                                return $resset;
                            }
                        }public function getVFirstname($id){
                            $query = "select vFirstname from users where iId=$id;";
                            if($resset = $this->conn->query($query)){
                                return $resset;
                            }
                        }public function getVLastname($id){
                            $query = "select vLastname from users where iId=$id;";
                            if($resset = $this->conn->query($query)){
                                return $resset;
                            }
                        }public function getDBirthdate($id){
                            $query = "select dBirthdate from users where iId=$id;";
                            if($resset = $this->conn->query($query)){
                                return $resset;
                            }
                        }public function getVPassword($id){
                            $query = "select vPassword from users where iId=$id;";
                            if($resset = $this->conn->query($query)){
                                return $resset;
                            }
                        }
                    
        
                    //insert data
                    public function insertData($arr){
                        extract($arr);
                        $password = sha1($pass);
                        $date = new DateTime($birthdate);
                        $birthdate = date_format($date, 'Y-m-d');
                        $query = "insert into users (vUsername, vFirstname, vLastname, dBirthdate, vPassword) values ('$username','$firstname','$lastname','$birthdate','$password');";
                  
                            if($this->conn->query($query)){
                                return true;
                            }else{
                                return false;
                            }
                           
                    }
                    
                }
                    