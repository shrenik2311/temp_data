<?php

require './User.php';
session_start();
 
$cookieValue = $_COOKIE['key'];
$sessionValue = $_SESSION['key'];
if($cookieValue === $sessionValue){
    if(isset($_SESSION['user'])){
        if('array' == gettype($_SESSION['user'])){
            
            $user = $_SESSION['user'];
            echo "<h1>Hii ".$user['vFirstname']." ".$user['vLastname']."</h1>";
            echo "<a href='logout.php' style='background-color:red;color:white;font-size:20px;padding:10px;border-radius:10%;'>Logout</a>";
            exit;
        }else{
            header('Location: index.php');
        }
    }
    header('Location: index.php');
}
header('Location: index.php');
?>