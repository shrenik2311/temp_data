 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="{{ asset("style.css")}}">
</head>
<body>
    <div class="operations"> 
        @auth
            <span class=""><a href="{{ route('dashboard') }}">Dashboard</a></span><br><br>
        @else
            <span class=""><a href="{{ route('login') }}">Log in</a></span><br><br>
            <span class=""><a href="{{ route('register') }}">Register</a></span>

        @endauth
    </div>
</body>
</html>
 